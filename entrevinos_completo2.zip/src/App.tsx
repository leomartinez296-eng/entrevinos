export default function App(){
  return <div style={{padding:20, fontSize:20}}>entrevinos.uy – base OK</div>;
}